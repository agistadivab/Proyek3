document.addEventListener("DOMContentLoaded", function () {
    const peopleList = document.querySelector(".people-list");
    const followedPeople = document.querySelector(".followed-people");
  
    peopleList.addEventListener("click", function (event) {
      if (event.target.classList.contains("follow-btn")) {
        const person = event.target.closest(".person");
        const personId = person.getAttribute("data-id");
  
        if (event.target.textContent === "Follow") {
          // Add to followed list
          const clonedPerson = person.cloneNode(true);
          const unfollowBtn = document.createElement("unfollow-btn");
          unfollowBtn.className = "unfollow-btn";
          unfollowBtn.textContent = "Unfollow";
          clonedPerson.appendChild(unfollowBtn);
          followedPeople.appendChild(clonedPerson);
  
          event.target.textContent = "Following";
        } else if (event.target.textContent === "Unfollow") {
          // Remove from followed list
          const followedPerson = followedPeople.querySelector(`[data-id="${personId}"]`);
          followedPerson.remove();
  
          const originalFollowBtn = person.querySelector(".follow-btn");
          originalFollowBtn.textContent = "Follow";
        }
      }
    });
  
    followedPeople.addEventListener("click", function (event) {
      if (event.target.classList.contains("unfollow-btn")) {
        const followedPerson = event.target.closest(".person");
        const personId = followedPerson.getAttribute("data-id");
        const originalPerson = peopleList.querySelector(`[data-id="${personId}"]`);
        const originalFollowBtn = originalPerson.querySelector(".follow-btn");
        originalFollowBtn.textContent = "Follow";
  
        followedPerson.remove();
      }
    });
  });
